# Generated BentoService bundle - SklearnBentoml:20221228114104_3F5E7B

This is a ML Service bundle created with BentoML, it is not recommended to edit
code or files contained in this directory. Instead, edit the code that uses BentoML
to create this bundle, and save a new BentoService bundle.
