from datetime import datetime, timezone
from autogluon.tabular import TabularDataset, TabularPredictor
from . import read_data
from . import autoML_Classification_Preprocessing
from . import Service
from . utils import generate_plots, get_arguments
import re
import json
import requests
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split

import base64
from sklearn.preprocessing import *
from sklearn.metrics import *
from sklearn.base import ClassifierMixin

import os
import pickle
import logging
import psutil

logger = logging.getLogger()

def autogluon(label, trainx_y, arguments):
    limit_secs = arguments.get('limit_secs')
    presets_value = arguments.get('presets_value')
    hyp_values = arguments.get('hyp_values')
    excluded_model_types = arguments.get('excluded_model_types')
    save_path = 'AGModels'
    predictor = TabularPredictor(label=label, path=save_path, verbosity=4).fit(trainx_y, presets=presets_value, time_limit=limit_secs, hyperparameters=hyp_values, excluded_model_types=excluded_model_types)
    return predictor

def smap(f):
    return f()
    
class autoML_classification:
    def __init__(self, target):
        self.df = ""
        self.random_state = 42
        self.label = target
        self.target_col = target
        self.pipe = ""
        self.test_data_nolab = ""
        self.output = {}
        self.le_flag = 'N'

    def start_automl_classification(self,userid, serviceid, spacekey, isfile , experimentId, projectId, created_by, experimentName, PrepDetails):
        try:
            output_data = {}
            start_time = datetime.now(timezone.utc)
            logger.info(f"(Starting AutoML) ====> CPU USAGE: {psutil.cpu_percent()}%, TIME TAKEN: {((datetime.now(timezone.utc) - start_time).total_seconds()/60):.2f}m")
            output_data["Task type"] = "Classification"
            output_data["Primary Matric"] = "Accuracy"
            output_data["Created time"] =start_time.strftime("%d/%m/%Y %H:%M:%S")
            output_data["created_by"] = created_by
            output_data['target_column'] = self.target_col
            self.df = read_data.get_data(serviceid, userid, isfile, spacekey, output_data, {}, PrepDetails)
            if isinstance(self.df, pd.DataFrame):
                self.sendStatus(spacekey, userid, experimentId, 2)
                try:
                    self.send_websocket_data(experimentId, {'success': 'true', 'content': "automl process is running"}, userid,
                                             spacekey)
                except Exception as e:
                    pass
            else:
                delta = datetime.now(timezone.utc) - start_time
                output_data["Updated time"] = datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M:%S")
                output_data["status"] = "Failed"
                output_data["error"] = "no dataframe"
                output_data["duration"] = delta.total_seconds()/60
                try:
                    self.send_websocket_data(experimentId, {'success': 'false', 'content': output_data}, userid,
                                             spacekey)
                except Exception as e:
                    pass
                self.sendStatus(spacekey, userid, experimentId, 4, "no dataframe")
                return {'success': 'false', 'content': output_data}

            from sklearn.preprocessing import LabelEncoder

            self.df[self.label] = (self.df[self.label]).fillna(method="bfill").fillna(method="ffill")
            self.le = LabelEncoder()

            if (self.df[self.label]).dtype not in ['int64', 'float64']:
                if pd.api.types.infer_dtype(self.df[self.label]) == 'string':
                    try:
                        if pd.api.types.infer_dtype(pd.to_datetime(self.df[self.label])) == 'datetime64':
                            raise Exception('Date type feature cannot be used as a target')
                    except:
                        if (self.df[self.label].nunique() == len(self.df) or self.df[self.label].nunique() >= 0.5 * len(self.df)):
                            raise Exception('Modeling of textual variables is not supported')
                else:
                    self.df[self.label] = self.le.fit_transform(self.df[self.label])
                    self.le_flag = 'Y'

            elif (self.df[self.label].dtype == 'float64', self.df[self.label].dtype == 'int64'):
                if (self.df[self.label].nunique() == len(self.df) or self.df[self.label].nunique() >= 0.5 * len(self.df)):
                    raise Exception('This is a Regression problem')

            if 0 not in (self.df[self.label].unique()).tolist():
                self.df[self.label] = self.le.fit_transform(self.df[self.label])
                self.le_flag = 'Y'
            try:
                train_data, test_data = train_test_split(self.df, test_size=0.1, random_state=self.random_state, stratify=self.df[self.label])
            except ValueError:
                train_data, test_data = train_test_split(self.df, test_size=0.1, random_state=self.random_state)
            y_test = test_data[self.label]  # values to predict
            self.test_data_nolab = test_data.drop(columns=[self.label])  # delete label column to prove we're not cheating
            X_train, y_train = (train_data.drop(self.target_col, axis=1), train_data[self.target_col])
            X_valid, y_valid = (test_data.drop(self.target_col, axis=1), test_data[self.target_col])

            self.pipe = autoML_Classification_Preprocessing.Preprocessor(label_enc=True, iterative_imputer=True, apply_cardinality_reduction=False,
                                cardinal_method='cluster',
                                cardinal_features=[], apply_Zero_NearZero_Variance=False, club_rare_levels=False,
                                rare_level_threshold_percentage=0.05, apply_untrained_levels_treatment=False,
                                untrained_levels_treatment_method="least frequent", non_linear_features=False,
                                apply_binning=False, features_to_binn=[], remove_outliers=False, feature_generator=False,
                                cluster_entire_data=False, range_of_clusters_to_try=20,
                                feature_selector=False, random_state=self.random_state
                                )

            autoML_Classification_Preprocessing.Preprocessor.__module__ = "autoML_Classification_Preprocessing"
            X_train = self.pipe.fit_transform(X_train, y_train)
            X_valid = self.pipe.transform(X_valid)
            pickle.dump(self.pipe, open('transform.pkl', 'wb'))

            trainx_y = pd.concat([X_train, y_train.reset_index(drop=True)], axis=1)
            validx_y = pd.concat([X_valid, y_valid.reset_index(drop=True)], axis=1)
            testx_y = pd.concat([self.test_data_nolab, y_test], axis=1)
            # classifier = autoML_Classification_Preprocessing.MyClassifier()
            # parameters_g = [autoML_Classification_Models.KNN(), autoML_Classification_Models.DT(), autoML_Classification_Models.RF()] #, autoML_Classification_Models.GB() 
            # parameters_r = [autoML_Classification_Models.XGB(), autoML_Classification_Models.AdaBoost(), autoML_Classification_Models.SGD()]

            # from multiprocessing import Pool
            # import functools

            # ret_id2 = functools.partial(autogluon, self.label, trainx_y)
            # ret_id3 = functools.partial(RS, parameters_r, X_train, y_train)
            # ret_id4 = functools.partial(GS, parameters_g, X_train, y_train)

            # with Pool() as pool:
            #     res = pool.map(smap, [ret_id2, ret_id3, ret_id4])
            # ag, rs, gs = res
            # pool.close()
            # ray.shutdown()
            # ray.init()

            # ret_id2 = autogluon.remote(self.label, trainx_y)
            # ag = ray.get([ret_id2])
            # ag = ag[0]
            ag = autogluon(self.label, trainx_y, get_arguments(self.df))
            print("multiprocessing completed")
            logger.info(f"(Model Training Completed) ====> CPU USAGE: {psutil.cpu_percent()}%, TIME TAKEN: {((datetime.now(timezone.utc) - start_time).total_seconds()/60):.2f}m")

            # To mitigate error in show_plots' Partial Dependence Plot.
            ag._estimator_type = 'classifier'
            ag.classes_ = ag.class_labels
            # To mitigate NotFittedError
            ag.dummy_ = 'dummy'


            def get_name(model_name):
                pattern = r"\("
                # pattern = r"(\w+)\("
                result = re.split(pattern, model_name)
                return result[0]

            if (self.df[self.label].nunique() == 2):
                columns = ['Model', 'Best_Score(Accuracy)', 'Best_Score(ROC_AUC)', 'Best_Score(Log_Loss)','Best_Score(F1)', 'Best_Score(precision)', 'Best_Score(recall)', 'Best_Score(MCC)', 'Fit_Time']
                # 1. Getting metrics information for top-3 AutoGluon models from leaderboard.
                ag_meta = ag.leaderboard(validx_y, extra_info=True, extra_metrics=['accuracy', 'roc_auc', 'log_loss', 'f1', 'precision', 'recall', 'mcc'],
                                            silent=True).head(3)[['model', 'accuracy', 'roc_auc', 'log_loss', 'f1', 'precision', 'recall', 'mcc', 'fit_time']]
                ag_meta.columns = columns


            else:
                columns = ['Model', 'Best_Score(Accuracy)', 'Best_Score(Balanced_Accuracy)', 'Best_Score(Log_Loss)', 'Best_Score(MCC)', 'Fit_Time']
                # 1. Getting metrics information for top-3 AutoGluon models from leaderboard.
                ag_meta = ag.leaderboard(validx_y, extra_info=True, extra_metrics=['accuracy', 'balanced_accuracy', 'log_loss', 'mcc'],
                                            silent=True).head(3)[['model', 'accuracy', 'balanced_accuracy', 'log_loss', 'mcc', 'fit_time']]
                ag_meta.columns = columns

            model_list = []
            for i, row in ag_meta.iterrows():
                model_list.append(row['Model'])

            top_k = pd.DataFrame(columns=columns)
            top_k = pd.concat([top_k, ag_meta], ignore_index=True)
            top_k.Model = top_k.Model.apply(get_name)
            top_k = top_k.sort_values(by=['Best_Score(Accuracy)'], ascending=False).reset_index(drop=True)
            if ag_meta.shape[0] > 1:
                if top_k.iloc[0, 1] == top_k.iloc[1, 1]:
                    if top_k.iloc[0, 2] == top_k.iloc[1, 2]:
                        top_k = top_k.sort_values(by=['Best_Score(Log_Loss)'], ascending=True).reset_index(drop=True)

            self.output['top models'] = top_k.to_json()

            self.output['metric'] = "accuracy"
            best_model = top_k.Model[0]
            self.output['model_score'] = top_k['Best_Score(Accuracy)'][0]
            self.output['best_model'] = best_model
            logger.info(f"(Saving Models...) ====> CPU USAGE: {psutil.cpu_percent()}%, TIME TAKEN: {((datetime.now(timezone.utc) - start_time).total_seconds()/60):.2f}m")
            model_resp = self.save_model(model_list, projectId, userid, spacekey,experimentName)
            logger.info(f"(Model Saved) ====> CPU USAGE: {psutil.cpu_percent()}%, TIME TAKEN: {((datetime.now(timezone.utc) - start_time).total_seconds()/60):.2f}m")
            if model_resp['success'] == False:
                delta = datetime.now(timezone.utc) - start_time
                output_data["Updated time"] = datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M:%S")
                output_data["status"] = "Failed"
                output_data["error"] = model_resp['Message']
                output_data["duration"] = delta.total_seconds() / 60
                try:
                    self.send_websocket_data(experimentId, {'success': 'false', 'content':output_data}, userid, spacekey)
                except Exception as e:
                    pass
                self.sendStatus(spacekey, userid, experimentId, 4, model_resp['Message'])
                return {'success': 'false', 'content':output_data}
            target_class = train_data[self.label].unique()[0]  # can be any possible value of the label column
            metrics_data = {}
            plots_data = {}
            for index, row in top_k.iterrows():
                model_name = row['Model']
                model = pickle.load(open(f'AGModels/models/{model_name}/model.pkl', 'rb'))
                if model_name == 'NeuralNetFastAI':
                    if model._load_model:
                        from fastai.learner import load_learner
                        from autogluon.core.utils.loaders import load_pkl
                        model.model = load_pkl.load_with_fn(f'{model.path}{model.model_internals_file_name}', lambda p: load_learner(p))
                    model._load_model = None

                if model_name == 'NeuralNetTorch':
                    if model._architecture_desc is not None:
                        import torch
                        from autogluon.tabular.models.tabular_nn.torch.torch_network_modules import EmbedNet

                        # recreate network from architecture description
                        model.model = EmbedNet(problem_type=model.problem_type,
                                            num_net_outputs=model._get_num_net_outputs(),
                                            quantile_levels=model.quantile_levels,
                                            architecture_desc=model._architecture_desc,
                                            device=model.device)
                        model._architecture_desc = None
                        model.model = torch.load(model.path + model.params_file_name)

                if model_name == 'NeuralNetMxnet':
                    if model._architecture_desc is not None:
                        from autogluon.tabular.models.tabular_nn.torch.torch_network_modules import EmbedNet
                        model.model = EmbedNet(architecture_desc=model._architecture_desc, ctx=model.ctx)  # recreate network from architecture description
                        model._architecture_desc = None
                        # TODO: maybe need to initialize/hybridize?
                        model.model.load_parameters(model.path + model.params_file_name, ctx=model.ctx)
                        model.summary_writer = None
                # # To mitigate NotFittedError
                model.dummy_ = 'dummy'
                # To mitigate error in show_plots' Partial Dependence Plot.
                model._estimator_type = 'classifier'
                model.classes_ = ag.class_labels
                logger.info(f"(Creating Matrix for model {index}) ====> CPU USAGE: {psutil.cpu_percent()}%, TIME TAKEN: {((datetime.now(timezone.utc) - start_time).total_seconds()/60):.2f}m")
                metrics_data[row['Model']] = self.show_scores(X_valid, y_valid, validx_y, model, testx_y, serviceid)
                logger.info(f"(Generating Plots for model {index}) ====> CPU USAGE: {psutil.cpu_percent()}%, TIME TAKEN: {((datetime.now(timezone.utc) - start_time).total_seconds()/60):.2f}m")
                plots_data[row['Model']] = self.show_plots(ag, X_valid, serviceid, model_name=model_name, validx_y=validx_y, model=model, X_train=X_train)
                logger.info(f"(Plots Generated for model {index}) ====> CPU USAGE: {psutil.cpu_percent()}%, TIME TAKEN: {((datetime.now(timezone.utc) - start_time).total_seconds()/60):.2f}m")

            self.output["metrics_data"] = metrics_data
            self.output["plots"] = plots_data
            name = "data_" + str(experimentId) + ".json"
            logger.info(f"(Saving Artifacts) ====> CPU USAGE: {psutil.cpu_percent()}%, TIME TAKEN: {((datetime.now(timezone.utc) - start_time).total_seconds()/60):.2f}m")
            artifact_data = {}
            delta = datetime.now(timezone.utc) - start_time
            artifact_data["Updated time"] = datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M:%S")
            artifact_data["status"] = "completed"
            artifact_data["duration"] = delta.total_seconds() / 60
            artifact_data.update(output_data)
            arti_data = {**artifact_data, **self.output}
            art_resp = Service.save_artifact(arti_data, name, spacekey, experimentId=experimentId, UserId=userid)
            if art_resp['success'] == False:
                delta = datetime.now(timezone.utc) - start_time
                output_data["Updated time"] = datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M:%S")
                output_data["status"] = "Failed"
                output_data["error"] =art_resp['Message']
                output_data["duration"] = delta.total_seconds() / 60
                try:
                    self.send_websocket_data(experimentId, {'success': 'false', 'content': output_data}, userid, spacekey)
                except Exception as e:
                    pass
                self.sendStatus(spacekey, userid, experimentId, 4, art_resp['Message'])
                return {'success': 'false', 'content': output_data}
            self.sendStatus(spacekey, userid, experimentId, 3, "completed successfully")
            delta = datetime.now(timezone.utc) - start_time
            output_data["Updated time"] = datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M:%S")
            output_data["status"] = "completed"
            output_data["duration"] = delta.total_seconds() / 60
            self.output.update(output_data)
            try:
                self.send_websocket_data(experimentId, {'success': 'true', 'content': output_data}, userid, spacekey)
            except Exception as e:
                print("websocket Exception")
                print(e)
            plt.close('all')
            logger.info(f"(Experiment Completed) ====> CPU USAGE: {psutil.cpu_percent()}%, TIME TAKEN: {((datetime.now(timezone.utc) - start_time).total_seconds()/60):.2f}m")
            return {'success': 'true', 'content': self.output }
        except Exception as e:
            delta = datetime.now(timezone.utc) - start_time
            output_data["Updated time"] = datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M:%S")
            output_data["status"] = "Failed"
            output_data["error"] = str(e)
            output_data["duration"] = delta.total_seconds() / 60
            self.sendStatus(spacekey, userid, experimentId, 4, str(e))
            self.send_websocket_data(experimentId, {'success': 'false', 'content': output_data}, userid, spacekey)
            return {'success': 'false', 'content': output_data}


    def sendStatus(self, spacekey, userid, experimentId, status, msg = "none"):
        url = str(os.getenv('PL_BASE_LAYER'))
        url = url + "/BizVizEP/services/rest/notebook/createAutoML"
        headers = {
            'SHARDKEY': spacekey, 'USERID': userid,  "Content-Type": "application/json"

        }
        payload = json.dumps({
         "panotebook":{
           "autoML": {
            "id": int(experimentId),
            "status": status,
            "logs": msg
                 }
            }
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        print("response of send status")
        print(response.json())
        return


    def send_websocket_data(self, experimentId, data, userId, spaceKey):
        response = "none"
        import urllib.parse
        if experimentId is not None:
            try:
                baseUrl = str(os.getenv('WEBSOCKET_URL'))
                url = baseUrl + "/cxf/bizviz/pluginServiceRouter"
                datas = json.dumps({
                    "key": experimentId, "userId": userId,
                    "spaceKey": spaceKey, "data": data})
                info = json.dumps({
                    "destination": "bizvizwebsocket", "datas": datas
                })
                print(info)
                info = urllib.parse.quote(info, encoding='utf-8')
                payload = "data=" + info + "&consumerName=BIZVIZAMQPRODUCER&serviceName=saveProcessToQuee"
                headers = {
                    'isRouter': 'true', 'isSecure': 'false',
                    'authtoken': '', 'spacekey': spaceKey, 'userID': userId,
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
                response = requests.request("POST", url, headers=headers, data=payload)
                print("\nwebsocket response\n")
                print(response.status_code)
            except Exception as e:
                print(e)
            return response

    from sklearn.base import BaseEstimator
    class AutogluonWrapper(BaseEstimator, ClassifierMixin):
        def __init__(self, predictor, feature_names, target_class=None):
            self.ag_model = predictor
            self.feature_names = feature_names
            self.target_class = target_class
            if target_class is None and self.ag_model.problem_type != 'regression':
                print("Since target_class not specified, SHAP will explain predictions for each class")

        def predict_proba(self, X):
            if isinstance(X, pd.Series):
                X = X.values.reshape(1, -1)
            if not isinstance(X, pd.DataFrame):
                X = pd.DataFrame(X, columns=self.feature_names)
            preds = self.ag_model.predict_proba(X)
            if self.ag_model.problem_type == "regression" or self.target_class is None:
                return preds
            else:
                return preds[self.target_class]

        def predict(self, X):
            if isinstance(X, pd.Series):
                X = X.values.reshape(1, -1)
            if not isinstance(X, pd.DataFrame):
                X = pd.DataFrame(X, columns=self.feature_names)
            preds = self.ag_model.predict(X)
            if self.ag_model.problem_type == "regression" or self.target_class is None:
                return preds
            else:
                return preds[self.target_class]

    def save_model(self, model_list, projectId, userid, spacekey, experimentName):
        for i in model_list:
            model_name = i
            expName = f"{experimentName}_{model_name}.pkl"
            filename = "AGModels/models/"
            if 'Weighted' in model_name:
                model = pickle.load(open(f'AGModels/models/{model_name}/model.pkl', 'rb'))
                model_list = list(model.base_model_paths_dict.keys())
                model_list.append(model_name)
            else:
                model_list = [model_name]

            res = Service.save_native(expName, spacekey, experimentId=projectId, UserId=userid, modelType="am", dirr=filename, Model_Name = model_name, model_list=model_list)
        
        return res

    def show_scores(self, X_valid, y_valid, validx_y, model, testx_y, serviceid):
        try:
            data = {}
            y_pred = model.predict(X_valid)
            cm = confusion_matrix(y_valid, y_pred)
            if self.le_flag =='Y':
                class_names = np.unique(self.le.inverse_transform(y_valid))
            else:
                class_names = y_valid.unique()

            data['confusion_matrix_plot'] = {'class_names': class_names, 'values':cm.tolist()}

            if self.le_flag =='Y':
                labels = np.unique(self.le.inverse_transform(self.df[self.label]))
                y_valid_invtr = self.le.inverse_transform(y_valid)
                y_pred_invtr = self.le.inverse_transform(y_pred)
                data['Performance Metrics'] = json.dumps(classification_report(y_valid_invtr, y_pred_invtr, labels=labels, output_dict=True))
            else:
                labels = (self.df[self.label].unique()).tolist()
                data['Performance Metrics'] = json.dumps(classification_report(y_valid, y_pred, labels=labels, output_dict=True))

            data_valid = validx_y.copy()
            data_valid.reset_index(inplace=True)
            if self.le_flag =='Y':
                data_valid[self.label] = self.le.inverse_transform(data_valid[self.label])

            if self.le_flag =='Y':
                data_valid["Predicted"] = self.le.inverse_transform(y_pred)
            else:
                data_valid["Predicted"] = y_pred

            test_data_lab = testx_y.copy()
            test_data_lab.reset_index(inplace=True)
            if self.le_flag =='Y':
                test_data_lab[self.label] = self.le.inverse_transform(test_data_lab[self.label])

            if self.le_flag == 'Y':
                test_data_lab["Predicted"] = self.le.inverse_transform(model.predict(self.pipe.transform(self.test_data_nolab)))
            else:
                test_data_lab["Predicted"] = model.predict(self.pipe.transform(self.test_data_nolab))

            return data
        except Exception as e:
            print(e)
            return str(e)


    def show_plots(self, ag, X_valid, serviceid, model_name, validx_y, model, X_train):
        plot_output = {}
        plot_output['Partial_Dependence_Plot_classification'] = []
        plot_output['ICE_Plot_classification'] = []
        def top2_important(shap_values, X):
            vals = np.abs(shap_values.values).mean(0)
            feature_importance = pd.DataFrame(list(zip(X.columns, vals.mean(0))),
                                                columns=['col_name', 'feature_importance_vals'])
            feature_importance.sort_values(by=['feature_importance_vals'], ascending=False, inplace=True)
            return feature_importance

        try:
            feature_importance = ag._learner.get_feature_importance(model=model_name, X=validx_y)
            feature_importance.sort_values(by=['importance'], ascending=False, inplace=True)
            zero, one = feature_importance.index[0], feature_importance.index[1]
            feature_importance_json = pd.DataFrame({'col_name':feature_importance.index, 'feature_importance_vals':feature_importance['importance']}).reset_index(drop=True).to_json()
            plot_output['feature_importance'] = feature_importance_json

            if (feature_importance.loc[zero]['importance']>0 and feature_importance.loc[one]['importance']>0):
                if (self.df[self.label].nunique() == 2):
                    generate_plots(model, X_valid, [zero], serviceid, plot_output, 'classification')
                else:
                    generate_plots(model, X_valid, [zero], serviceid, plot_output, 'classification')

            else:
                import shap
                ag_wrapper = self.AutogluonWrapper(predictor=model, feature_names=X_train.columns)
                f = lambda x: ag_wrapper.predict_proba(x)
                med = X_train.median().values.reshape((1, X_train.shape[1]))

                explainer = shap.Explainer(f, med)
                shap_values = explainer(X_train.iloc[0:10, :])

                feature_importance = top2_important(shap_values, X_valid)
                feature_importance = feature_importance.reset_index(drop=True)


                zero, one = feature_importance['col_name'][0], feature_importance['col_name'][1]
                feature_importance = feature_importance.to_json()
                plot_output['feature_importance'] = feature_importance

                if (self.df[self.label].nunique() == 2):
                    generate_plots(model, X_valid, [zero], serviceid, plot_output, 'classification')
                else:
                    generate_plots(model, X_valid, [zero], serviceid, plot_output, 'classification')

                return plot_output
                # raise ValueError('the feature importance value is 0, cannot plot PDP and ICE plots')
        except Exception as e:
            print(e)
            return str(e)

        return plot_output