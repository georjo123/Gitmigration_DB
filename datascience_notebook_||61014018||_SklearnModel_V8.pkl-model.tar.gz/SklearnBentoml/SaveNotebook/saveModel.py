from bentoml import env, artifacts, api, BentoService
from bentoml.frameworks.sklearn import SklearnModelArtifact
import bentoml
import logging.config
from typing import List
import numpy as np
from PIL import Image
from bentoml.frameworks.keras import KerasModelArtifact
from bentoml.adapters import ImageInput,DataframeInput,FileInput, JsonOutput, JsonInput
import torch
from torchvision import transforms
from bentoml.frameworks.pytorch import PytorchModelArtifact
from bentoml.frameworks.lightgbm import LightGBMModelArtifact
import string 
from bentoml.service.artifacts.common import PickleArtifact
from keras.preprocessing import text, sequence
import pandas as pd
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import text_to_word_sequence


logging.config.dictConfig({
    'version': 1,
    # Other configs ...
    'disable_existing_loggers': True
})

# sklearn
@env(infer_pip_packages=True)
@artifacts([SklearnModelArtifact('model')])
class SklearnBentoml(BentoService):
    @api(input=DataframeInput(), batch=True)
    def predict(self, df):
        return self.artifacts.model.predict(df)


# keras for cv
@env(pip_packages=['keras==2.9.0', 'tensorflow==2.7', 'pillow==9.1.1', 'numpy==1.21.6'])
@artifacts([KerasModelArtifact('model')])
class KerasBentoml(BentoService):
    @api(input=ImageInput(pilmode='L'), batch=True)
    def predictcv(self, imgs: List[np.ndarray],imgsize:tuple, dim:tuple) -> List[str]: 
        inp = transpose()
        inputs = inp.transpose(imgs,imgsize,dim)
        return self.artifacts.model.predict(inputs)  
    @api(input=DataframeInput(), batch=True)
    def predictml(self, data):
        return self.artifacts.model.predict(data)

class transpose:
    def transpose(self,imgs: List[np.ndarray],imgsize:tuple, dim=1  ):
        inputs = []
        for img in imgs:
            img = Image.fromarray(img).resize(imgsize)
            imgsize = imgsize + (dim,)
            img = np.array(img.getdata()).reshape(imgsize)
            inputs.append(img)
        inputs = np.stack(inputs)
        return inputs


# pytorch for cv
@bentoml.env(pip_packages=['torch==1.11.0', 'numpy==1.21.6', 'torchvision==0.12.0', 'scikit-learn==1.0.2','spacy==3.3.0'])
@bentoml.artifacts([PytorchModelArtifact('model')])
class pyTorchBentoml(bentoml.BentoService):
    
    @bentoml.utils.cached_property  # reuse transformer
    def transform(self):
        return transforms.Compose([transforms.CenterCrop((29, 29)), transforms.ToTensor()])

    @bentoml.api(input=FileInput(), output=JsonOutput(), batch=True)
    def predictcv(self, imgs, class_names):
        img_tensors = []
        for fs in imgs:
            img = Image.fromarray(fs)
            img_tensors.append(self.transform(img))
            self.artifacts.model.eval()
        outputs = self.artifacts.model(torch.stack(img_tensors))
        _, output_classes = outputs.max(dim=1)
        if class_names:
            return [class_names[output_class] for output_class in output_classes]
        else:
            return outputs
     
    @api(input=DataframeInput(), batch=True)
    def predictml(self, data):
        self.artifacts.model.eval()
        return self.artifacts.model(data)

# lightgbm
@bentoml.artifacts([LightGBMModelArtifact('model')])
@bentoml.env(pip_packages=['lightgbm==3.3.2'])
class lightgbmbentoml(bentoml.BentoService): 
    @bentoml.api(input=DataframeInput(), batch=True)
    def predict(self, df, features:list):
        data = df[features]
        return self.artifacts.model.predict(data)

#statsmodel
@env(pip_dependencies=["statsmodels==0.13.2","joblib==1.1.0","numpy==1.21.6"])
@artifacts([PickleArtifact('model')])
class statsmodelbento(BentoService):
    @api(input=DataframeInput(), batch=True)
    def forecast(self, df):
        return((self.artifacts.model).forecast(df))
    def predict(self, start,end):   
        return((self.artifacts.model).predict(start,end))


#NLP SKLEARN
@bentoml.artifacts([PickleArtifact('model')])
@bentoml.env(pip_packages=["scikit-learn==1.1.1", "pandas==1.3.5"])
class SklearnNLP(bentoml.BentoService):

    @bentoml.api(input=DataframeInput(), batch=True)
    def predict(self, df):
        """
        predict expects pandas.Series as input
        """        
        series = df.iloc[0,:]
        return self.artifacts.model.predict(series)

#NLP KERAS  
def preprocess(s):
    return strip_punctuation(remove_br(s.lower()))


def strip_punctuation(s):
    for c in string.punctuation + "’":
        s = s.replace(c, "")
    return s


def remove_br(s):
    return s.replace("<br /><br />", "")

list_of_classes = ["toxic", "severe_toxic", "obscene", "threat", "insult", "identity_hate"]
max_text_length = 400

@env(pip_packages=['tensorflow==2.7','scikit-learn==1.0.2','pandas==1.3.5'], docker_base_image="bentoml/model-server:0.12.1-py38-gpu")
@artifacts([KerasModelArtifact('model'), PickleArtifact('tokenizer')])
class KerasNLP(BentoService):
    def word_to_index(self, word):
        if word in self.artifacts.tokenizer and self.artifacts.tokenizer[word] <= 5000:
            return self.artifacts.tokenizer[word]
        else:
            return self.artifacts.tokenizer["<OOV>"]

    def preprocessing(self, text_str):
        proc = text_to_word_sequence(preprocess(text_str))
        tokens = list(map(self.word_to_index, proc))
        return tokens

    @api(input=JsonInput())
    def predict_dict(self, parsed_json):
        raw = self.preprocessing(parsed_json['text'])
        input_data = [raw[: n + 1] for n in range(len(raw))]
        input_data = pad_sequences(input_data, maxlen=100, padding="post")
        return self.artifacts.model.predict(input_data)
    
    def tokenize_df(self, df):
        comments = df['comment_text'].values
        tokenized = self.artifacts.tokenizer.texts_to_sequences(comments)        
        input_data = sequence.pad_sequences(tokenized, maxlen=max_text_length)
        return input_data    
    
    @api(input=DataframeInput(), output=JsonOutput(), batch=True)
    def predict(self, input_data,class_names = None) -> List[str]:
        prediction = self.artifacts.model.predict(input_data)
        result = []
        for i in prediction:
            result.append(class_names[np.argmax(i)] if class_names else np.argmax(i))
        return result